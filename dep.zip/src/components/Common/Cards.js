const Cards = ({ children, className }) => {
  return <div className={className}>{children}</div>;
};

export default Cards;
