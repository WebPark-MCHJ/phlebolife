module.exports = {
  i18n: {
    locales: ["ru", "uz"],
    defaultLocale: "ru",
  },
};
