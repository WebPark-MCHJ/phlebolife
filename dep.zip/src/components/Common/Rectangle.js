const Rectangle = ({ children }) => {
  return <div className="rectangle">{children}</div>;
};

export default Rectangle;
